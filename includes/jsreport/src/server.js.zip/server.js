var tmp = require('tmp');
var fs = require('fs');
var path = require('path');
var stream = require('stream');
var phantomPath = require('phantomjs-prebuilt').path;
var driver = require('../lib/node-phantom-simple/node-phantom-simple');

/** Need to include base and reportbuilder utilities here to run in Node context */
var jsreports = require('./jsreports-base');
require('./reportbuilder')(jsreports);

var clientJS = require('raw!uglify!../build/jsreports-all-bundle.js');
var jQueryJS = require('raw!../lib/jquery-1.11.0.min.js');
var babelPolyfillJS = require('raw!../node_modules/babel-polyfill/dist/polyfill.min.js');
var fonts = {
  'Roboto-Bold.ttf': require('base64!./fonts/Roboto-Bold.ttf'),
  'Roboto-BoldItalic.ttf': require('base64!./fonts/Roboto-BoldItalic.ttf'),
  'Roboto-Italic.ttf': require('base64!./fonts/Roboto-Italic.ttf'),
  'Roboto-Regular.ttf': require('base64!./fonts/Roboto-Regular.ttf')
};

var maxWorkers = 3;
var availableWorkers = [];
var busyWorkers = [];
var phantomStartPort = 11000;
var maxTasksPerWorker = 50;
var lastPruneTime = 0;
var pruneIntervalMs = 10000;
var taskTimeoutMs = 60000;
var pendingTasks = [];
var startingWorkers = 0;
var DEBUG = false;

var debugLogger = {
  log: console.log,
  warn: console.log,
  debug: console.log,
  error: console.log
};

var phantomJsParams = {
  'web-security': 'false',
  'local-to-remote-url-access': 'true',
  'ignore-ssl-errors': 'true'
};

function unpackFile(str, filePrefix, fileExtension) {
  var file = tmp.fileSync({ prefix: filePrefix, postfix: fileExtension });
  fs.appendFileSync(file.name, str);
  return file.name;
}

var clientJSPath = unpackFile(clientJS, 'jsreports-client-js-', '.js');
var jqueryJSPath = unpackFile(jQueryJS, 'jsreports-jquery-js-', '.js');
var babelPolyfillJSPath = unpackFile(babelPolyfillJS, 'jsreports-babel-polyfill-js-', '.js');

var libraryPath = tmp.dirSync().name;
fs.mkdirSync(path.resolve(libraryPath, 'fonts'));
Object.keys(fonts).forEach(function(fontFilename) {
  var wstream = fs.createWriteStream(path.resolve(libraryPath, 'fonts', fontFilename));
  wstream.write(new Buffer(fonts[fontFilename], 'base64'));
  wstream.end();
});

var singleton = null;

var ServerAPI = function(cfg) {
  if (singleton) throw new Error('Multiple Server instances not supported.');
  singleton = this;
  if (!cfg) cfg = {};
  this.cfg = cfg;
  if (cfg.maxWorkers) maxWorkers = cfg.maxWorkers;
  if (cfg.maxTasksPerWorker) maxTasksPerWorker = cfg.maxTasksPerWorker;
  if (cfg.libraryPath) libraryPath = cfg.libraryPath;
  DEBUG = !!cfg.debug;
  if (DEBUG) {
    console.log('Using PhantomJS at', phantomPath);
  }
  this.status = 'running';
};

function getPhantomInstance(renderCallback) {
  var me = this;
  if (new Date() - lastPruneTime > pruneIntervalMs) {
    pruneWorkers();
  }
  if (availableWorkers.length > 0) {
    return engageWorker(availableWorkers.pop(), renderCallback);
  }
  if (busyWorkers.length + startingWorkers < maxWorkers) {
    return newWorker(function(err, worker) {
      // Server might have been stopped while PhantomJS was starting
      if (singleton.status !== 'running') {
        return disposeWorker(worker);
      }
      if (err) return renderCallback(err);
      return engageWorker(worker, renderCallback);
    });
  }
  // No available workers; queue the task
  pendingTasks.unshift(renderCallback);
}

function engageWorker(worker, renderCallback) {
  busyWorkers.push(worker);
  worker.phantom.createPage(function(err, page, phantom) {
    if (err) {
      disposeWorker(worker);
      return getPhantomInstance(renderCallback);
    }
    worker.page = page;
  renderCallback(null, worker);
  });
}

function releaseWorker(worker) {
  if (worker.page) {
    worker.page.close();
  }
  busyWorkers.splice(busyWorkers.indexOf(worker), 1);
  if (++worker.taskCount >= maxTasksPerWorker) {
    disposeWorker(worker);
  } else {
    availableWorkers.unshift(worker);
  }
  if (pendingTasks.length > 0) {
    getPhantomInstance(pendingTasks.pop());
  }
}

function removeItemIfExists(arr, item) {
  var ix = arr.indexOf(item);
  if (ix >= 0) {
    arr.splice(ix, 1);
  }
}

function disposeWorker(worker) {
  try {
    worker.phantom.exit();
  } catch(e) {}
  removeItemIfExists(busyWorkers, worker);
  removeItemIfExists(availableWorkers, worker);
}

function newWorker(callback) {
  startingWorkers++;   
  var worker = {
    startTime: new Date(),
    taskCount: 0
  };
  driver.create({ 
    path: phantomPath, 
    parameters: phantomJsParams,
    logger: (DEBUG ? debugLogger : {})
  }, function (err, phantom) {
    startingWorkers--;
    if (err) return callback(err);
    if (DEBUG) {
      phantom.onError = function(msg, trace) {
        var msgStack = ['PHANTOMJS ERROR: ' + msg];
        if (trace && trace.length) {
          msgStack.push('TRACE:');
          trace.forEach(function(t) {
            msgStack.push(' -> ' + (t.file || t.sourceURL) + ': ' + t.line + (t.function ? ' (in function ' + t.function +')' : ''));
          });
        }
        console.error(msgStack.join('\n'));
        phantom.exit(1);
      };    
    }
    phantom.process.stderr.on('data', function(data) {
      console.error(data);
      // TODO handle crash
    });
    worker.phantom = phantom;
    callback(null, worker);
  });
}

function pruneWorkers() {
  var now = new Date();
  for (var i = busyWorkers.length - 1; i >= 0; i--) {
    if (now - busyWorkers[i].startTime > taskTimeoutMs) {
      disposeWorker(busyWorkers[i]);
      busyWorkers.splice(i, 1);
    }
  }
}

function requireLeadingSlash(str) {
  if (str === null) return str;
  if (str.indexOf('/') === 0) return str;
  return '/' + str;
}

/**
 * Renders a jsreports report on the server.  Accepts the same arguments as jsreports.export on the client.
 * Returns a Node stream to which the PDF or Excel output will be written.
 *
 * Required configuration parameters:
 * jQueryPath - path to jQuery JavaScript file on the server
 * jsreportsJSPath - path to jsreports JavaScript file on the server
 * jsreportsCSSPath - path to jsreports CSS file on the server
 *
 * Optional configuration parameters:
 * otherCSSPaths - array of additional CSS file paths to load when rendering the report
 */
ServerAPI.prototype.export = function(cfg, callback) {
  if (this.status !== 'running') throw new Error('Server is stopped.');
  var me = this;
  getPhantomInstance(function(err, worker) {
    if (err) return callback(err);
    var page = worker.page;
    var content = [
      '<!DOCTYPE html><html><head>',
      '<script type="text/javascript" src="file://' + requireLeadingSlash(babelPolyfillJSPath) + '"></script>',
      '<script type="text/javascript" src="file://' + requireLeadingSlash(jqueryJSPath) + '"></script>',
      '<script type="text/javascript" src="file://' + requireLeadingSlash(clientJSPath) + '"></script>',
      (me.cfg.otherCSSPaths || []).map(function(cssPath) {
        return '<link rel="stylesheet" href="file://' + requireLeadingSlash(cssPath) + '" />';
      }).join(''),
      '</head><body></body></html>'
    ].join('');
    page.onError = function(err) {
      releaseWorker(worker);
      return callback(err);
    };
    if (DEBUG) {
      page.onConsoleMessage = function(msg, lineNum, sourceId) {
        console.log('CONSOLE: ' + msg + ' (from line #' + lineNum + ' in "' + sourceId + '")');
      };
      page.onResourceRequested = function(request) {
        console.log('Request', request[0].url);
      };
      page.onResourceReceived = function(response) {
        console.log('Received', response.url, response.stage, response.status, response.statusText);
      };
      page.onResourceError = function(err) {
        console.log('Resource error', err.url, err.errorCode);
      };
    }
    page.onLoadFinished = function () {
      page.onCallback = function(b64) {
        var buf = new Buffer(b64, 'base64');
        var outStream = new stream.PassThrough();
        releaseWorker(worker);
        callback(null, outStream);
        outStream.end(buf);
      };
    page.evaluate(function(exportCfg, libPath, registeredFonts) {
      exportCfg.outputHandler = function(blob) {
        var blobToBase64 = function(blob, cb) {
          var reader = new FileReader();
          reader.onload = function() {
            var dataUrl = reader.result;
            var base64 = dataUrl.split(',')[1];
            cb(base64);
          };
          reader.readAsDataURL(blob);
        };
        blobToBase64(blob, function(base64Str) {
          window.callPhantom(base64Str);
        });
      };
      var jsreports = window.jsreports;
      jsreports.imageUrlPrefix = exportCfg.imageUrlPrefix;
      if (libPath) {
        jsreports.libraryPath = 'file://' + libPath;
      }
      registeredFonts.forEach(function(fontArgs) {
        jsreports.registerFont.apply(this, fontArgs);
      });
      jsreports.export(exportCfg);
    }, 
    cfg, requireLeadingSlash(libraryPath), registeredFonts, 
    // Callback for page.evaluate
    function(err, result) {
      if (err) {
        releaseWorker(worker);
        return callback(err);
      }
    });
    };
    page.set('content', content);
  });
};

ServerAPI.prototype.isIdle = function() {
  return (busyWorkers.length === 0 
    && pendingTasks.length === 0);
};

ServerAPI.prototype.stop = function() {
  if (this.status !== 'running') return;
  this.status = 'stopped';
  busyWorkers.concat(availableWorkers).forEach(function(worker) {
    disposeWorker(worker);
  });
  busyWorkers = [];
  availableWorkers = [];
};

ServerAPI.prototype.start = function() {
  this.status = 'running';
};

const registeredFonts = [];
/** 
 * Register a font face (a family, and optionally weight and style) for PDF font embedding.
 *
 * @param {string} family - The font family, e.g. Helvetica
 * @param {string} weight - The font weight, one of "normal" or "bold"
 * @param {string} style - The font style, one of "normal" or "italic"
 * @param {string} url - The file:// url of the font's .ttf file
 */
ServerAPI.prototype.registerFont = function(...args) {
  registeredFonts.push(args);
};

jsreports.Server = ServerAPI;

module.exports = jsreports;
